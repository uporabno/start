﻿function pridobiPodatke() {
    var url = 'https://api.coinmarketcap.com/v1/ticker/?limit=0&convert=EUR';
    console.log('Start');
    var promise = $.getJSON(url);
    promise.done(function(data) {
        ////////////////////////
        // največje spremembe //
        ////////////////////////        
        var binanceArr = [ 
            'ADA',   'ADX',   'AION',  'AMB',   'ARK',   'ARN',   'AST',   'BAT',   'BCC',   'BCD',   
            'BCPT',  'BNB',   'BNT',   'BQX',   'BTC',   'BTG',   'BTS',   'CDT',   'CMT',   'CND',   
            'CTR',   'DASH',  'DGD',   'DLT',   'DNT',   'ELF',   'ENG',   'ENJ',   'EOS',   'ETC',   
            'ETH',   'EVX',   'FUEL',  'FUN',   'GAS',   'GTO',   'GVT',   'GXS',   'HSR',   'ICN',   
            'ICX',   'IOTA',  'KMD',   'KNC',   'LEND',  'LINK',  'LRC',   'LSK',   'LTC',   'MANA',  
            'MCO',   'MDA',   'MOD',   'MTH',   'MTL',   'NEO',   'NULS',  'OAX',   'OMG',   'OST',   
            'POE',   'POWR',  'PPT',   'QSP',   'QTUM',  'RCN',   'RDN',   'REQ',   'SALT',  'SNGLS', 
            'SNM',   'SNT',   'STORJ', 'STRAT', 'SUB',   'TNB',   'TNT',   'TRX',   'VEN',   'VIB',   
            'WABI',  'WAVES', 'WTC',   'XLM',   'XMR',   'XRP',   'XVG',   'XZC',   'YOYO',  'ZEC',   
            'ZRX'];
        
        var myTop1h = [];
        var myTop24h = [];
        var myTop7d = [];
        
        for(var j=0; j<data.length; j++) {
            var percent_change_1h  = parseFloat(data[j].percent_change_1h);
            var percent_change_24h = parseFloat(data[j].percent_change_24h);
            var percent_change_7d  = parseFloat(data[j].percent_change_7d);
            var x24h_volume_eur    = parseFloat(data[j]["24h_volume_eur"]);
            if (data[j].percent_change_1h == null) percent_change_1h = 0;
            if (data[j].percent_change_24h == null) percent_change_24h = 0;
            if (data[j].percent_change_7d == null) percent_change_7d = 0;
            if (data[j]["24h_volume_eur"] == null) x24h_volume_eur = 0;
            x24h_volume_eur = precise_round(x24h_volume_eur, 0);
            myTop1h[myTop1h.length] = { symbol:             data[j].symbol,
                                        name:               data[j].name,
                                        price_eur:          parseFloat(data[j].price_eur),
                                        percent_change_1h:  percent_change_1h,
                                        percent_change_24h: percent_change_24h,
                                        percent_change_7d:  percent_change_7d,
                                        x24h_volume_eur:    x24h_volume_eur
                                      };
            myTop24h[myTop24h.length] = { symbol:           data[j].symbol,
                                        name:               data[j].name,
                                        price_eur:          parseFloat(data[j].price_eur),
                                        percent_change_1h:  percent_change_1h,
                                        percent_change_24h: percent_change_24h,
                                        percent_change_7d:  percent_change_7d,
                                        x24h_volume_eur:    x24h_volume_eur
                                      };
            myTop7d[myTop7d.length] = { symbol:             data[j].symbol,
                                        name:               data[j].name,
                                        price_eur:          parseFloat(data[j].price_eur),
                                        percent_change_1h:  percent_change_1h,
                                        percent_change_24h: percent_change_24h,
                                        percent_change_7d:  percent_change_7d,
                                        x24h_volume_eur:    x24h_volume_eur
                                      };
        }    
        
        myTop1h.sort(function(a,b) {return (a.percent_change_1h < b.percent_change_1h) ? 1 : ((b.percent_change_1h < a.percent_change_1h) ? -1 : 0);} );  
        myTop24h.sort(function(a,b) {return (a.percent_change_24h < b.percent_change_24h) ? 1 : ((b.percent_change_24h < a.percent_change_24h) ? -1 : 0);} );  
        myTop7d.sort(function(a,b) {return (a.percent_change_7d < b.percent_change_7d) ? 1 : ((b.percent_change_7d < a.percent_change_7d) ? -1 : 0);} );  
        
        for(var r=0; r<100; r++) {
            // 1h
            //console.log(myTop1h[r].symbol+'-'+myTop1h[r].name+' = '+precise_round(myTop1h[r].percent_change_1h, 1)+'%');
            document.getElementById("top1h_valuta_v" + r).innerHTML = '<a href="https://www.google.si/search?q='+ myTop1h[r].symbol +'+site:coinmarketcap.com" target="_blank">'
                                                                                + myTop1h[r].symbol + '</a><br/><small>' + myTop1h[r].name + '</small>';
            if (binanceArr.indexOf(myTop1h[r].symbol) > -1) {
                document.getElementById("top1h_valuta_v" + r).innerHTML = document.getElementById("top1h_valuta_v" + r).innerHTML +
                                                                          '<font color="red">@Binance</font>';
            } 
            if (myTop1h[r].x24h_volume_eur >= 100000) {
                document.getElementById("top1h_valuta_v" + r).innerHTML = document.getElementById("top1h_valuta_v" + r).innerHTML +
                                                                          '<font color="green"><br/>' + numberWithCommas(myTop1h[r].x24h_volume_eur) + ' €</font>';
            }
            else {
                document.getElementById("top1h_valuta_v" + r).innerHTML = document.getElementById("top1h_valuta_v" + r).innerHTML +
                                                                          '<font color="silver"><br/>' + numberWithCommas(myTop1h[r].x24h_volume_eur) + ' €</font>';
            }
            document.getElementById("top1h_tecaj_v"  + r).innerHTML = '<small>' + precise_round(myTop1h[r].price_eur, 4) + ' €';
            document.getElementById("top1h_spr1h_v"  + r).innerHTML = '<small>' + precise_round(myTop1h[r].percent_change_1h, 1)+' %</small>';
            document.getElementById("top1h_spr24h_v" + r).innerHTML = '<small>' + precise_round(myTop1h[r].percent_change_24h, 1)+' %</small>';
            document.getElementById("top1h_spr7d_v"  + r).innerHTML = '<small>' + precise_round(myTop1h[r].percent_change_7d, 1)+' %</small>';
            // 24h
            //console.log(myTop24h[r].symbol+'-'+myTop24h[r].name+' = '+precise_round(myTop24h[r].percent_change_24h, 1)+'%');
            document.getElementById("top24h_valuta_v" + r).innerHTML = '<a href="https://www.google.si/search?q='+ myTop24h[r].symbol +'+site:coinmarketcap.com" target="_blank">'
                                                                                 + myTop24h[r].symbol + '</a><br/><small>' + myTop24h[r].name + '</small>';
            if (binanceArr.indexOf(myTop24h[r].symbol) > -1) {
                document.getElementById("top24h_valuta_v" + r).innerHTML = document.getElementById("top24h_valuta_v" + r).innerHTML +
                                                                          '<font color="red">@Binance</font>';
            } 
             if (myTop24h[r].x24h_volume_eur >= 100000) {
                document.getElementById("top24h_valuta_v" + r).innerHTML = document.getElementById("top24h_valuta_v" + r).innerHTML +
                                                                          '<font color="green"><br/>' + numberWithCommas(myTop24h[r].x24h_volume_eur) + ' €</font>';
            }
            else {
                document.getElementById("top24h_valuta_v" + r).innerHTML = document.getElementById("top24h_valuta_v" + r).innerHTML +
                                                                          '<font color="silver"><br/>' + numberWithCommas(myTop24h[r].x24h_volume_eur) + ' €</font>';
            }
            document.getElementById("top24h_tecaj_v"  + r).innerHTML = '<small>' + precise_round(myTop24h[r].price_eur, 4) + ' €</small>';
            document.getElementById("top24h_spr1h_v"  + r).innerHTML = '<small>' + precise_round(myTop24h[r].percent_change_1h, 1)+' %</small>';
            document.getElementById("top24h_spr24h_v" + r).innerHTML = '<small>' + precise_round(myTop24h[r].percent_change_24h, 1)+' %</small>';
            document.getElementById("top24h_spr7d_v"  + r).innerHTML = '<small>' + precise_round(myTop24h[r].percent_change_7d, 1)+' %</small>';
            // 7d
            //console.log(myTop7d[r].symbol+'-'+' = '+precise_round(myTop7d[r].percent_change_7d, 1)+'%   vrednost =' + precise_round(myTop7d[r].price_eur,4));
            document.getElementById("top7d_valuta_v" + r).innerHTML = '<a href="https://www.google.si/search?q='+ myTop7d[r].symbol +'+site:coinmarketcap.com" target="_blank">'
                                                                                + myTop7d[r].symbol + '</a><br/><small>' + myTop7d[r].name + '</small>';
            if (binanceArr.indexOf(myTop7d[r].symbol) > -1) {
                document.getElementById("top7d_valuta_v" + r).innerHTML = document.getElementById("top7d_valuta_v" + r).innerHTML +
                                                                          '<font color="red">@Binance</font>';
            } 
            if (myTop7d[r].x24h_volume_eur >= 100000) {
                document.getElementById("top7d_valuta_v" + r).innerHTML = document.getElementById("top7d_valuta_v" + r).innerHTML +
                                                                          '<font color="green"><br/>' + numberWithCommas(myTop7d[r].x24h_volume_eur) + ' €</font>';
            }
            else {
                document.getElementById("top7d_valuta_v" + r).innerHTML = document.getElementById("top7d_valuta_v" + r).innerHTML +
                                                                          '<font color="silver"><br/>' + numberWithCommas(myTop7d[r].x24h_volume_eur) + ' €</font>';
            }
            document.getElementById("top7d_tecaj_v"  + r).innerHTML = '<small>' + precise_round(myTop7d[r].price_eur, 4) + ' €</small>';
            document.getElementById("top7d_spr1h_v"  + r).innerHTML = '<small>' + precise_round(myTop7d[r].percent_change_1h, 1)+' %</small>';
            document.getElementById("top7d_spr24h_v" + r).innerHTML = '<small>' + precise_round(myTop7d[r].percent_change_24h, 1)+' %</small>';
            document.getElementById("top7d_spr7d_v"  + r).innerHTML = '<small>' + precise_round(myTop7d[r].percent_change_7d, 1)+' %</small>';
        }
        console.log('Done');
    });
    promise.fail(function() {
      console.log('Fail');
    });
    promise.always(function() {
      //console.log('Allways='+tecaj);
    });
}





function precise_round(num, decimals) {
   var t = Math.pow(10, decimals);   
   return (Math.round((num * t) + (decimals>0?1:0)*(Math.sign(num) * (10 / Math.pow(100, decimals)))) / t).toFixed(decimals);
}


function numberWithCommas(n) {
    var parts=n.toString().split(".");
    return parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",") + (parts[1] ? "." + parts[1] : "");
}


function getImgValuta(p_valuta) {
    var ime = '';
    if (p_valuta.toLowerCase() == 'btc') ime = 'bitcoin';
    if (p_valuta.toLowerCase() == 'eth') ime = 'ethereum';
    if (p_valuta.toLowerCase() == 'xrp') ime = 'ripple';
    if (p_valuta.toLowerCase() == 'ltc') ime = 'litecoin';
    if (p_valuta.toLowerCase() == 'miota') ime = 'iota';
    if (p_valuta.toLowerCase() == 'ada') ime = 'cardano';
    if (p_valuta.toLowerCase() == 'xlm') ime = 'stellar';
    if (p_valuta.toLowerCase() == 'neo') ime = 'neo';
    if (p_valuta.toLowerCase() == 'powr') ime = 'power-ledger';
    if (p_valuta.toLowerCase() == 'xvg') ime = 'verge';
    if (p_valuta.toLowerCase() == 'eos') ime = 'eos';
    if (p_valuta.toLowerCase() == 'rdn') ime = 'raiden-network-token';
    if (p_valuta.toLowerCase() == 'qsp') ime = 'quantstamp';
    if (p_valuta.toLowerCase() == 'sub') ime = 'substratum';
    if (p_valuta.toLowerCase() == 'blx') ime = 'blockchain-index';
    
    return '<a href="https://coinmarketcap.com/currencies/' + ime + '">' + 
           '<img src="img/' + p_valuta.toLowerCase() + '.png" height="16" width="16"></a>&nbsp;';
}


function getImgLokacija(p_valuta) {
    if (p_valuta.toLowerCase() == 'bitstamp') {
        return '<a href="https://www.bitstamp.net">' + 
               '<img src="img/' + p_valuta.toLowerCase() + '.png" class="img-circle" height="32" width="32"></a>' +
               '&nbsp;';
    }
    else if (p_valuta.toLowerCase() == 'ledger nano s') {
        return '<a href="https://www.ledgerwallet.com/products/ledger-nano-s">' + 
               '<img src="img/' + p_valuta.toLowerCase() + '.png" class="img-circle" height="32" width="32"></a>' +
               '&nbsp;';
    }
    else if (p_valuta.toLowerCase() == 'binance') {
        return '<a href="https://www.binance.com">' + 
               '<img src="img/' + p_valuta.toLowerCase() + '.png" class="img-circle" height="32" width="32"></a>' +
               '&nbsp;';
    }
    else if (p_valuta.toLowerCase() == 'iconomi') {
        return '<a href="https://www.iconomi.net/dashboard/#/">' + 
               '<img src="img/' + p_valuta.toLowerCase() + '.png" class="img-circle" height="32" width="32"></a>' +
               '&nbsp;';
    }    
    else {
        return '<img src="img/' + p_valuta.toLowerCase() + '.png" class="img-circle" height="32" width="32"></a>&nbsp;';
    }
}

