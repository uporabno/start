﻿function pridobiPodatke() {
//https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest?convert=EUR&limit=300
//X-CMC_PRO_API_KEY
//5e0a05ec-1654-491d-81d6-106e18e4e732

    //var url = 'https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest?convert=EUR&limit=300'; 
    var url = 'https://cors-anywhere.herokuapp.com/https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest?convert=EUR&limit=300'; 

    
    var myObject = {"X-CMC_PRO_API_KEY" : "5e0a05ec-1654-491d-81d6-106e18e4e732"
                    //,"Access-Control-Allow-Origin": "*"
                   };
    var promise = $.getJSON(url, myObject); //var promise = $.getJSON(url, {_: new Date().getTime()});
    //var promise = $.getJSON(url); //var promise = $.getJSON(url, {_: new Date().getTime()});
    console.log('Start');
    promise.done(function(data) {
        console.log('Reading done.');
        // preberi vse valute        
        var myValute = [];

        // dopolni s tečajem
        //for(var j=0; j<data.length; j++) {
        console.log('Done');
        
        
    });
    promise.fail(function() {
      console.log('Fail');
      //document.getElementById("sum_all").innerHTML = 'Ni podatkov';
    });
    promise.always(function() {
      //console.log('Allways='+tecaj);
    });




}

